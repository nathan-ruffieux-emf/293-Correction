# Model-Personal-Project
Project description
## Pourquoi ce thème ?
J'ai choisit ce thème simplement car je pense connaitre asser le jeu pour pouvoir en faire un site internet. Le sujet étant facile pour moi, cela me laissera plus de temps pour travailler sur les fonctionnalités et l'ésthétique du site.
## Quelle est l'utilité du site ?
Il permettera aux nouveaux joueurs de comprendre le jeu grâce à des explication simples et précise ( par exemple sur comment débuter dans le jeu, quels sont les types d'armes, ...)

