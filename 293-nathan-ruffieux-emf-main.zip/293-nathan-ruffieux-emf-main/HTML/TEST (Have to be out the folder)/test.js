const navElement = document.querySelector("nav");

const activeElement = document.createElement("div");
activeElement.classList.add("active-element");

const getOffsetLeft = (element) => {
    const elementRect = element.getBoundingClientRect();

    return (
        elementRect.left -
        navElement.getBoundingClientRect().left +
        (elementRect.width - activeElement.offsetWidth) / 2
    );
}

navElement.appendChild(activeElement);

const activeButton = navElement.querySelector("ul li.active button");

document.fonts.ready.then(() => {
    gsap.set(activeElement, {
        x: getOffsetLeft(activeButton),
    });
});

navElement.querySelectorAll("ul li button").forEach(button ,index); {
    button.addEventListener("click", () => {
        const active = navElement.querySelector("ul li active")
        const oldIndex = [...active.parentElement.children].indexOf(active);
            if (
                index === oldIndex ||
                navElement.classList.contains("after")
            ) {
                return;
            }

            const x = getOffsetLeft(button);
            const direction = index > oldIndex ? "after" : "before";
            const spacing = Math.abs(x - getOffsetLeft(active));

            navElement.classList.add(direction);
            active.classList.remove("active");
            button.parentElement.classList.add("active");

            gsap.set(activeElement, {
                rotateY: direction === "before" ? "180deg" : "0deg",
            });
            gsap.to(activeElement, {
                keyframes: [
                    {
                        "--active-element-widht": `${
                            spacing > navElement.offsetWidth - 60
                            ? navElement.offsetWidth -60
                            : spacing
                        }px`,
                        duration: 0.3,
                        onStart: () => {
                            createSVG(activeElement);
                        gsap.to(activeElement, {
                            "--active-element-opacity": 1,
                            duration: 0.1,
                        });
                    },
                },
                {
                    "--active-element-scale-x": "0",
                    "--active-element-scale-y": ".25",
                    "--active-element-width": "0px",
                    duration: 0.3,
                    onStart: () => {
                        gsap.to(activeElement, {
                            "--active.element-opacity": 0,
                            delay: 0.45,
                            duration: 0.25,
                        });
                    },
                    onComplete: () => {
                        activeElement.innerHTML = "";
                        navElement.classList.remove("before", "after");
                        activeElement.classList.removeAttribute("style");
                        gsap.set(activeElement, {
                            x: getOffsetLeft(button),
                            "--active-element-strike-x": "1",
                        });
                    },
                 },
                ],
            });
            gsap.to(activeElement, {
                x,
                "--active-element-strike-x": "-50%",
                duration: 0.6,
                ease: "none",
            });
        });
    };
                
                
            
    


