function openPanel() {
    document.getElementById("myPanel").style.display = "flex";
  }

  function closePanel() {
    document.getElementById("myPanel").style.display = "none";
  }

  // Function to check if the user pressed Enter and close the panel if the input contains "NUKE"
  function checkForEnterAndK(event) {
    if (event.key === 'Enter') {
      var inputText = document.getElementById("inputInPanel").value.toUpperCase();
      if (inputText.includes("NUKE")) {
        closePanel();
        showSlidingImages(); // Call the function to show the sliding images
      }
    }
  }

  document.addEventListener("keydown", function(event) {
    if (event.key === 'k') {
      openPanel();
    }
  });

  function showSlidingImages() {
    const slidingImage1 = document.getElementById('slidingImage1');
    const slidingImage2 = document.getElementById('slidingImage2');
    const slidingImage3 = document.getElementById('slidingImage3');

    // Move the first sliding image from left to right
    slidingImage1.style.left = '100%';

    // Delay the start of the second sliding image
    setTimeout(() => {
      // Move the second sliding image from top to bottom
      slidingImage2.style.top = '100%';
      // Make the second image visible by adjusting opacity
      slidingImage2.style.opacity = 1;
    }, 3500); // Adjust the delay for the second image (in milliseconds)

    // Delay the appearance of the third sliding image
    setTimeout(() => {
      // Make the third image visible by adjusting opacity
      slidingImage3.style.opacity = 1;
    }, 7000); // Adjust the delay for the third image (in milliseconds)
  }