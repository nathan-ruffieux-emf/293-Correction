function changerpuce(imgid) {
    var img = document.getElementById(imgid);
    if (img.src.match(/MilitaryCrate/)) {
        img.src = "image/codepaper3.png";
    }
}

